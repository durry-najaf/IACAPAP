(function($) {

$(document).ready(function() {
    //alert("OK");
});

})(jQuery);