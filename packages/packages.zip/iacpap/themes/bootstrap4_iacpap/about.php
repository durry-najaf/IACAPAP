<?php defined('C5_EXECUTE') or die("Access Denied."); ?>
<?php $view->inc('elements/header.php'); ?>
<div class="page-header">
            <div class="container">
                <div class="heading-section wow animate__pulse">
                    <h1>SHAPING THE FUTURE</h5>
                        <h4>05 - 09 DECEMBER 2022</h3>
                </div>
            </div>
        </div>
        <div class=" upcoming-section wow animate__fadeInLeft">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="right-img">
                            <img src="<?php echo $view->getThemePath() ?>/images/upcoming.png" alt="">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="left-content">
                            <h3>UPCOMING IACAPAP WORLD CONGRESS 2022 </h3>
                            <h1>Global conference of mental health professionals to be held fro</h1>
                            <h6>
                                Dubai is first Arab city to host the prestigious biannual world congress The International Association of Child and Adolescent Psychiatrists and Allied Professionals (IACAPAP), in collaboration with Al Jalila Children’s Specialty Hospital (AJCH), has
                                launched the logo for its 25th World Congress set to be held from 19 to 25 March 2022 in Dubai. To be held under the theme of ‘Child and Adolescent Mental Health: Shaping the Future’, IACAPAP 2022 Dubai will provide a platform
                                for discussing the world’s latest research, exploring the current mental health challenges of children adolescents and highlighting new cutting-edge tools for improving mental health.
                            </h6>
                            <button class="btn btn-primary orange-btn">Read More</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="about-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="text-section wow animate__fadeInRight">
                            <h6>ABOUT AL JALILA</h6>
                            <h2>Al Jalila Children’s Specialty Hospital</h2>
                            <p>
                                Al Jalila Children’s is the first dedicated children’s hospital in the United Arab Emirates. The state of the art paediatric medical facility was created under the directives of His Highness Sheikh Mohammed Bin Rashid Al Maktoum, Vice President and Prime
                                Minister of the UAE, and Ruler of Dubai, to affirm his belief that all children should have an equal opportunity for success in life, and the treatment of children suffering from illness or disease should not be subject
                                to geographical chance. The hospital is a place where SMART technology and design converge to enhance patient care and outcomes. It hosts the first robotic pharmacy in Dubai, and a fully automated laboratory. The hospital
                                also aims to foster clinical innovations, astute learning and development programmes and cutting-edge research facilities.
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6 wow animate__backInDown">
                        <div class="right-img"><img src="<?php echo $view->getThemePath() ?>/images/Confrence-1.jpg" alt=""></div>
                    </div>
                </div>
            </div>

        </div>
        <div class="about-organisation-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="right-img wow animate__backInDown"><img src="<?php echo $view->getThemePath() ?>/images/about2.png" alt=""></div>
                    </div>
                    <div class="col-lg-6">
                        <div class="text-section wow animate__fadeInRight">
                            <h6>ABOUT IACAPAP</h6>
                            <h2>THE ORGANISATION</h2>
                            <p>
                                The International Association for Child and Adolescent Psychiatry and Allied Professions (IACAPAP) is registered as a not-for-profit association in Switzerland, and is recognised by the World Health Organization (WHO) as an official non-state actor in
                                child & adolescent psychiatry and mental health.
                            </p>
                            <button class="btn btn-primary orange-btn">Read More</button>
                        </div>
                    </div>
                </div>
                <div class="team-section">
                    <div class="heading">
                        <h1>HISTORY OF IACAPAP</h1>
                        <p>
                            Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                        </p>
                    </div>
                    <div class="slider">
                        <div class="carousel-wrap">
                            <div class="owl-carousel">
                                <div class="item"><img src="<?php echo $view->getThemePath() ?>/images/slide1.jpg"></div>
                                <div class="item"><img src="<?php echo $view->getThemePath() ?>/images/slide2.jpg"></div>
                                <div class="item"><img src="<?php echo $view->getThemePath() ?>/images/slide3.jpg"></div>
                                <div class="item"><img src="<?php echo $view->getThemePath() ?>/images/slide1.jpg"></div>
                                <div class="item"><img src="<?php echo $view->getThemePath() ?>/images/slide2.jpg"></div>
                                <div class="item"><img src="<?php echo $view->getThemePath() ?>/images/slide3.jpg"></div>
                                <div class="item"><img src="<?php echo $view->getThemePath() ?>/images/slide1.jpg"></div>
                                <div class="item"><img src="<?php echo $view->getThemePath() ?>/images/slide2.jpg"></div>
                                <div class="item"><img src="<?php echo $view->getThemePath() ?>/images/slide3.jpg"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="bottom-cards-section">
            <div class="container">
                <div class="row wow animate__zoomIn">
                    <div class="col-lg-6">
                        <div class="left-box">
                            <h3>OUR MISSION</h3>
                            <p>
                                The mission of IACAPAP is to promote child and adolescent psychiatry and the mental health and development of children and adolescents, through policy, practice, training and research. To achieve its global mission, IACAPAP has a wide range of activities.
                                These include a bi-annual world congress, a freely accessible e-textbook, a massively online open course (MOOC), and two early career development programmes (the Donald J Cohen Fellowship and Helmut Remschmidt Research
                                Seminars). IACAPAP also makes position statements, and publishes position papers and monographs to promote child & adolescent psychiatry and mental health around the globe. On social media, it promotes its activities through
                                a quarterly Bulletin, through Facebook and twitter, and through its website.

                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="right-box">
                            <h3>IACAPAP’s goals for the following years are to:</h3>
                            <ul>
                                <li>
                                    Support organisations devoted to promoting the mental health of children and adolescents;
                                </li>
                                <li>
                                    Disseminate information and foster training through multidisciplinary study groups, congresses, publications and other educational initiatives;
                                </li>
                                <li>
                                    Strengthen the bonds between the different regions of the world to promote multi-disciplinary, multi-professional research and clinical practice in child and adolescent mental health (CAMH).
                                </li>
                            </ul>
                            <p>In addition, IACAPAP will promote international, state and community policies within all sectors of human services to ensure evidence-based, culturally acceptable, affordable and accessible mental health services are available
                                for all children and adolescents.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="history-section">
            <div class="container">
                <div class="heading">
                    <h1>OVERSIGHT COMMITTEE</h1>
                    <p>
                        MEMBERS OF THE BUREAU
                    </p>
                </div>
                <div class="slider">
                    <div class="carousel-wrap">
                        <div class="owl-carousel">
                            <div class="item">
                                <div class="team-member">
                                    <img src="<?php echo $view->getThemePath() ?>/images/team-1.jpg" alt="">
                                    <div class="text-content">
                                        <p>Name Here</p>
                                        <small>Designation</small>
                                    </div>

                                </div>
                            </div>
                            <div class="item">
                                <div class="team-member">
                                    <img src="<?php echo $view->getThemePath() ?>/images/team-2.jpg" alt="">
                                    <div class="text-content">
                                        <p>Name Here</p>
                                        <small>Designation</small>
                                    </div>

                                </div>
                            </div>
                            <div class="item">
                                <div class="team-member">
                                    <img src="<?php echo $view->getThemePath() ?>/images/team-3.jpg" alt="">
                                    <div class="text-content">
                                        <p>Name Here</p>
                                        <small>Designation</small>
                                    </div>

                                </div>
                            </div>
                            <div class="item">
                                <div class="team-member">
                                    <img src="<?php echo $view->getThemePath() ?>/images/team-4.jpg" alt="">
                                    <div class="text-content">
                                        <p>Name Here</p>
                                        <small>Designation</small>
                                    </div>

                                </div>
                            </div>
                            <div class="item">
                                <div class="team-member">
                                    <img src="<?php echo $view->getThemePath() ?>/images/team-1.jpg" alt="">
                                    <div class="text-content">
                                        <p>Name Here</p>
                                        <small>Designation</small>
                                    </div>

                                </div>
                            </div>
                            <div class="item">
                                <div class="team-member">
                                    <img src="<?php echo $view->getThemePath() ?>/images/team-2.jpg" alt="">
                                    <div class="text-content">
                                        <p>Name Here</p>
                                        <small>Designation</small>  
                                    </div>

                                </div>
                            </div>
                            <div class="item">
                                <div class="team-member">
                                    <img src="<?php echo $view->getThemePath() ?>/images/team-3.jpg" alt="">
                                    <div class="text-content">
                                        <p>Name Here</p>
                                        <small>Designation</small>
                                    </div>

                                </div>
                            </div>
                            <div class="item">
                                <div class="team-member">
                                    <img src="<?php echo $view->getThemePath() ?>/images/team-4.jpg" alt="">
                                    <div class="text-content">
                                        <p>Name Here</p>
                                        <small>Designation</small>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hosted-section">
            <div class="container">
                <img src="<?php echo $view->getThemePath() ?>/images/host.png" style="width: 100%;" alt="">
            </div>
        </div>
    <?php $view->inc('elements/footer.php') ?>