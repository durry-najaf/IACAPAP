<?php defined("C5_EXECUTE") or die("Access Denied."); ?>
<?php if (isset($title) && trim($title) != "") { ?>
    <div class="sponsor-section">
        <div class="container">
            <h2><?php echo h($title); ?></h2><?php } ?>
<?php if (isset($Description_1) && trim($Description_1) != "") { ?>
    <h4><?php echo h($Description_1); ?></h4></div>
    </div><?php } ?>