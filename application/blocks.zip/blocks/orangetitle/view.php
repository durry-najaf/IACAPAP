<?php defined("C5_EXECUTE") or die("Access Denied."); ?>
<?php if (isset($orangetitle) && trim($orangetitle) != "") { ?>
    <div class="expect-section"><div class="heading"><h3 class="text-center"><?php echo h($orangetitle); ?> </h3></div></div><?php } ?>
	<style>
	.expect-section {
    min-height: 100% !important;    padding: 30px 0px !important;
	}
    </style>