<?php defined("C5_EXECUTE") or die("Access Denied."); ?>
<?php if (isset($title) && trim($title) != "") { ?>
    <div class="tipnUsefulls"><div class="textSec"><h2><?php echo $title; ?><h2></div></div><?php } ?>
	<style>.tipnUsefulls .textSec p {
    font-size: 20px;
    color: #454545;
    font-weight: 600;
    line-height: 2rem;
}
.tipnUsefulls .textSec h2 {
    font-size: 32px;
    color: #72c6a2;
    font-weight: 600;
}
</style>