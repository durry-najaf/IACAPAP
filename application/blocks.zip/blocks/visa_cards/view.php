<?php defined("C5_EXECUTE") or die("Access Denied."); ?>
<?php if (isset($title) && trim($title) != "") { ?>
    <div class="visaCards"> <div class="grayCards"><h5><?php echo $title; ?></h5></div></div><?php } ?>