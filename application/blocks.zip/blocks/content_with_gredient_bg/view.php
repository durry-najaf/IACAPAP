<?php defined("C5_EXECUTE") or die("Access Denied."); ?>
<?php if (isset($content) && trim($content) != "") { ?>
    <div class="belowVisa">
                <div class="secHeading"><?php echo $content; ?></div></div><?php } ?>