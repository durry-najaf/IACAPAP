<?php defined("C5_EXECUTE") or die("Access Denied."); ?>
<?php if (isset($title) && trim($title) != "") { ?>
    <h1 class="orangeLg"><?php echo h($title); ?></h1><?php } ?>
	<style>
    .orangeLg{
		font-size: 36px;
    color: #f7a193;
		}
    </style>